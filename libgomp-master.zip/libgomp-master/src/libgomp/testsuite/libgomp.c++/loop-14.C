/* { dg-do run } */

#include "../libgomp.c/loop-14.c"
