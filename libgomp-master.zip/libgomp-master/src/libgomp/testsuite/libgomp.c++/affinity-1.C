// { dg-do run }
// { dg-set-target-env-var OMP_PROC_BIND "true" }

#include "../libgomp.c/affinity-1.c"
