double f[1024];
double (&fr) [1024] = f;
double gbuf[1024];
double *g = gbuf;
double *&gr = g;
