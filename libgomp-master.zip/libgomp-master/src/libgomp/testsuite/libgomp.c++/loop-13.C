/* { dg-do run } */

#include "../libgomp.c/loop-13.c"
