// { dg-do run }

#include "../libgomp.c/udr-1.c"
