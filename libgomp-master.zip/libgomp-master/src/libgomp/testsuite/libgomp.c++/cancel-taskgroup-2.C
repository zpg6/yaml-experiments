// { dg-do run }
// { dg-set-target-env-var OMP_CANCELLATION "true" }

#include "../libgomp.c/cancel-taskgroup-2.c"
