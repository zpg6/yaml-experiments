// { dg-do run }
// { dg-options "-fopenmp -std=c++11" }

#include "udr-5.C"
