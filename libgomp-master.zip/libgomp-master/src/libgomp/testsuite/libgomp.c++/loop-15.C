/* { dg-do run } */

#include "../libgomp.c/loop-15.c"
